///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/****************************************************************/
// Campbell Update: Implementing LoadSceneTextures() function
// to ensure that each shape gets appropriate textures.
/****************************************************************/

/***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/

	// Campbell Update: adding appropriate code to load the textures from
	// the textures folder for the shapes in the scene.

	bool bReturn = false;

	// Adding marble floor texture for floor plane
	bReturn = CreateGLTexture("textures/marble-texture.jpg", "floor");

	// Adding stained glass texture for the lip, box & cylinder/neck of the vase
	bReturn = CreateGLTexture("textures/vase-texture.jpg", "vase");

	// Adding stained glass texture for the lip, box & cylinder/neck of the vase
	bReturn = CreateGLTexture("textures/water-texture.jpg", "water");

	// Adding green texture for the stem & bud of the flower
	bReturn = CreateGLTexture("textures/flower-texture.jpg", "flower");

	// Adding pink petal texture for the outer ring of petals of the flower
	bReturn = CreateGLTexture("textures/petal-texture.png", "petals");

	// Adding keyboard texture for the computer
	bReturn = CreateGLTexture("textures/keyboard.png", "keyboard");

	// Adding silvery/steel texture for the laptop/computer
	bReturn = CreateGLTexture("textures/steel-texture.jpg", "steel");

	// Adding wood texture for the pencil
	bReturn = CreateGLTexture("textures/pencil-wood.jpg", "pencil");

	// Adding gold texture for the frame of the glasses
	bReturn = CreateGLTexture("textures/gold-texture.jpg", "glasses");

	// Adding leather texture for the binding of the book
	bReturn = CreateGLTexture("textures/book-texture.jpg", "book");

	// Adding paper texture for the internal pages of the book
	bReturn = CreateGLTexture("textures/pages-texture.jpg", "pages");

	// Adding white porcelain texture for the mug
	bReturn = CreateGLTexture("textures/mug-texture.jpg", "mug");

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/****************************************************************/
// Campbell Update: Implementing DefineObjectMaterials() function
// to ensure that each object gets a specific shader
/****************************************************************/

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL goldMaterial;
	goldMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
	goldMaterial.specularColor = glm::vec3(0.7f, 0.7f, 0.6f);
	goldMaterial.shininess = 50.0;
	goldMaterial.tag = "metal";

	m_objectMaterials.push_back(goldMaterial);

	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	woodMaterial.specularColor = glm::vec3(0.0f, 0.0f, 0.0f);
	woodMaterial.shininess = 0.08;
	woodMaterial.tag = "wood";

	m_objectMaterials.push_back(woodMaterial);

	OBJECT_MATERIAL glassMaterial;
	glassMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	glassMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	glassMaterial.shininess = 95.0;
	glassMaterial.tag = "glass";

	m_objectMaterials.push_back(glassMaterial);

	OBJECT_MATERIAL mugMaterial;
	mugMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
	mugMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	mugMaterial.shininess = 30.0;
	mugMaterial.tag = "mug";

	m_objectMaterials.push_back(mugMaterial);

}

/****************************************************************/
// Campbell Update: Implementing SetupSceneLights() function
// to apply lighting to the entire scene.
/****************************************************************/

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene. 
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render 
	// the 3D scene with custom lighting - to use the default rendered 
	// lighting then comment out the following line
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Directional ambient light to emulate sunlight coming into scene from behind
	m_pShaderManager->setVec3Value("directionalLight.direction", -3.0f, 10.0f, 0.0f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.65f, 0.65f, 0.65f);
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// Diffuse light to simulate indoor lighting
	m_pShaderManager->setVec3Value("pointLights[0].position", -4.0f, 6.0f, 3.0f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.15f, 0.15f, 0.15f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.7f, 0.7f, 0.7f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
	
	// Specular bright yellow light source that would come from a lamp/light above the table
	m_pShaderManager->setVec3Value("pointLights[1].position", -2.0f, 8.0f, -1.0f);
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.05f, 0.05f, 0.05f);
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 0.4f, 0.4f, 0.2f);
	m_pShaderManager->setVec3Value("pointLights[1].specular", 1.0f, 1.0f, 0.7f);
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Campbell Update: adding appropriate functions to load the textures/shaders/lights for the 3D scene
	LoadSceneTextures();
	// define the materials that will be used for the objects in the 3D scene
	DefineObjectMaterials();
	// add and defile the light sources for the 3D scene
	SetupSceneLights();
	
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	m_basicMeshes->LoadPlaneMesh();

	/****************************************************************/
	// Campbell Update: Loading all other essential shapes to help construct
	// the mug, the books with glasses sitting atop them, the laptop, the
	// pencil, and the vase with a single flower in it.
	/****************************************************************/

	// Loading in Cylinder
	m_basicMeshes->LoadCylinderMesh();

	// Loading in Torus
	m_basicMeshes->LoadTorusMesh();

	// Loading in Box
	m_basicMeshes->LoadBoxMesh();

	// Loading in Cone
	m_basicMeshes->LoadConeMesh();

	// Loading in Tapered Cylinder
	m_basicMeshes->LoadTaperedCylinderMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// Campbell Update: Functions to render the individual
	// objects in the scene, each with their own unique shapes,
	// textures, and shaders for a fully complete scene.

	// Renders the floor/tabletop for the scene
	RenderTableTop();
	// Rightmost object, a vase & flower
	RenderVaseAndFlower();
	// Pencil that sits in front of vase and to the right of the laptop/computer
	RenderPencil();
	// Laptop/Computer that sits in the middle of the scene
	RenderComputer();
	// A book that's positioned to the left of the computer/laptop
	RenderBook();
	// Rendered glasses that sit atop the book
	RenderGlasses();
	// Final object, leftmost of the scene, a mug that holds a beverage
	RenderMug();	
}

/****************************************************************/
// Campbell Update: BEGINNING OF SECTION FOR TABLE TOP PLANE
/****************************************************************/
/***********************************************************
 *  RenderTableTop()
 *
 *  This method is called to render
 *  the shapes for the marble table object.
 ***********************************************************/
void SceneManager::RenderTableTop()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(17.0f, 1.0f, 7.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-2.5f, 0.0f, 1.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// marble texture for the floor.
	/****************************************************************/
	// SetShaderColor(0.82, 0.7, 0.54, 1);
	SetShaderTexture("floor");
	SetShaderMaterial("mug");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/
}
/****************************************************************/
// Campbell Update: END OF SECTION FOR TABLE TOP PLANE
/****************************************************************/

/****************************************************************/
// Campbell Update: BEGINNING OF SECTION FOR VASE & FLOWER
/****************************************************************/
/***********************************************************
 *  RenderVaseAndFlower()
 *
 *  This method is called to render
 *  the shapes for the vase and flower.
 ***********************************************************/
void SceneManager::RenderVaseAndFlower()
{
	// Create the body of the vase, using a box mesh

	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh ***/

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.0f, 4.0f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 30.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(8.0f, 2.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// stained glass texture for the box shape of the vase.
	/****************************************************************/
	// SetShaderColor(0.3, 0.3, 0.75, 0.5);
	SetShaderTexture("vase");
	SetShaderMaterial("glass");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// Create the neck of the vase

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 1.0f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(8.0f, 4.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// stained glass texture for the cylinder/neck shape of the vase.
	/****************************************************************/
	// SetShaderColor(0.3, 0.3, 0.75, 0.5);
	SetShaderTexture("vase");
	SetShaderMaterial("glass");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// Create the water in the vase

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 0.1f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(8.0f, 4.95f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// water texture for the shape inside the neck of the vase.
	/****************************************************************/
	// SetShaderColor(0.0, 1.0, 1.0, 1.0);
	SetShaderTexture("water");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// Create the lip of the vase

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 0.5f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(8.0f, 5.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// stained glass texture for the lip shape of the vase.
	/****************************************************************/
	// SetShaderColor(0.3, 0.3, 0.75, 0.5);
	SetShaderTexture("vase");
	SetShaderMaterial("glass");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTorusMesh();
	/****************************************************************/

	// Create the stem of the flower

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.1f, 6.0f, 0.1f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(8.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// flower texture for the stem of the flower.
	/****************************************************************/
	// SetShaderColor(0.10, 0.90, 0.10, 1.0);
	SetShaderTexture("flower");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// Create the base/bud of the flower (part where the petals come out)

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 0.3f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 135.0f;
	YrotationDegrees = 150.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(7.9f, 6.0f, 0.2f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// flower texture for the bud of the flower.
	/****************************************************************/
	// SetShaderColor(0.10, 0.90, 0.10, 1.0);
	SetShaderTexture("flower");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();
	/****************************************************************/

	// Create the petals of the flower

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.5f, 1.5f, 1.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 135.0f;
	YrotationDegrees = 150.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(7.90f, 5.90f, 0.40f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// ping petal texture for the outer set of petals to the flower.
	/****************************************************************/
	// SetShaderColor(0.90, 0.90, 0.10, 1.0);
	SetShaderTexture("petals");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/
}
/****************************************************************/
// Campbell Update: END OF SECTION FOR VASE & FLOWER
/****************************************************************/

/****************************************************************/
// Campbell Update: BEGINNING OF SECTION FOR PENCIL
/****************************************************************/
/***********************************************************
 *  RenderPencil()
 *
 *  This method is called to render
 *  the shapes for the pencil.
 ***********************************************************/
void SceneManager::RenderPencil()
{
	// Create the wooden base of the pencil
	
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.1f, 4.0f, 0.1f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 60.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(6.0f, 0.15f, 2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// wood texture for pencil.
	/****************************************************************/
	// SetShaderColor(0.54, 0.3, 0.0, 1);
	SetShaderTexture("pencil");
	SetShaderMaterial("wood");
	
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// Create the metal eraser holder at the end of the pencil

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.12f, 0.5f, 0.12f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 60.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(6.0f, 0.15f, 2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// grey texture for pencil eraser holder.
	/****************************************************************/
	// SetShaderColor(0.4, 0.4, 0.4, 1);
	SetShaderTexture("steel");
	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// Create the pink eraser the end of the pencil

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.1f, 0.25f, 0.1f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 60.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(6.05f, 0.15f, 1.9f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// pink texture for the eraser of the pencil.
	/****************************************************************/
	SetShaderColor(1.0, 0.6, 0.9, 1);

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// Create the graphite tip of the pencil

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.1f, 0.5f, 0.1f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 60.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(4.0f, 0.15f, 5.46f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// charcoal texture for the tip of the pencil.
	/****************************************************************/
	SetShaderColor(0.1, 0.1, 0.1, 1);
	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawConeMesh();
	/****************************************************************/
}
/****************************************************************/
// Campbell Update: END OF SECTION FOR PENCIL
/****************************************************************/

/****************************************************************/
// Campbell Update: BEGINNING OF SECTION FOR COMPUTER
/****************************************************************/
/***********************************************************
 *  RenderComputer()
 *
 *  This method is called to render
 *  the shapes for the laptop computer.
 ***********************************************************/
void SceneManager::RenderComputer()
{
	// Create the base of the laptop (where the keys/mousepad will be)

	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(7.0f, 0.2f, 9.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 70.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.2f, 2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// silver metal texture for the base of the computer.
	/****************************************************************/
	// SetShaderColor(0.7, 0.7, 0.7, 1);
	SetShaderTexture("steel");
	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// Create the keyboard plane at the middle of the base of the computer

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(3.75f, 3.75f, 1.75f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = -20.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.25f, 0.35f, 1.75f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// keyboard texture for the computer.
	/****************************************************************/
	// SetShaderColor(0.3, 0.3, 0.3, 1);
	SetShaderTexture("keyboard");
	SetShaderMaterial("glass");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	// Create the mousepad at the bottom of the base of the computer

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.75f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 70.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-0.5f, 0.35f, 4.4f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing in a black color and implementing
	// a glossy glass shader to the mousepad of the computer.
	/****************************************************************/
	SetShaderColor(0.2, 0.2, 0.2, 1);
	SetShaderMaterial("glass");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	// Create the back of the laptop, where the screen/display is

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(7.0f, 0.2f, 9.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 70.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.2f, 3.7f, -1.1f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// silver metal texture for the back of the computer.
	/****************************************************************/
	// SetShaderColor(0.7, 0.7, 0.7, 1);
	SetShaderTexture("steel");
	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	// Create the digital display of the laptop

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.75f, 0.0f, 3.75f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 70.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.2f, 3.75f, -0.9f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: White color to represent a blank
	// turned on digital screen for the laptop
	/****************************************************************/
	SetShaderColor(1.0, 1.0, 1.0, 1);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
}
/****************************************************************/
// Campbell Update: END OF SECTION FOR COMPUTER
/****************************************************************/

/****************************************************************/
// Campbell Update: BEGINNING OF SECTION FOR BOOK
/****************************************************************/
/***********************************************************
 *  RenderBook()
 *
 *  This method is called to render
 *  the shapes for a boos.
 ***********************************************************/
void SceneManager::RenderBook()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// Create the pages that will be the inside of the book

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 5.0f, 5.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-8.0f, 0.5f, -2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// page texture for the inside of the book.
	/****************************************************************/
	// SetShaderColor(1.0, 1.0, 1.0, 1);
	SetShaderTexture("pages");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// Create the top leather cover of the book

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.05f, 5.5f, 5.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-8.0f, 1.05f, -2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// page texture for the inside of the book.
	/****************************************************************/
	// SetShaderColor(1.0, 1.0, 1.0, 1);
	SetShaderTexture("book");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// Create the bottom leather cover of the book

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.05f, 5.5f, 5.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-8.0f, 0.05f, -2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// page texture for the inside of the book.
	/****************************************************************/
	// SetShaderColor(1.0, 1.0, 1.0, 1);
	SetShaderTexture("book");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// Create the spine of the book

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(5.5f, 0.05f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-8.0f, 0.55f, -4.75f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// page texture for the inside of the book.
	/****************************************************************/
	// SetShaderColor(1.0, 1.0, 1.0, 1);
	SetShaderTexture("book");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/
}
/****************************************************************/
// Campbell Update: END OF SECTION FOR BOOK
/****************************************************************/

/****************************************************************/
// Campbell Update: BEGINNING OF SECTION FOR GLASSES
/****************************************************************/
/***********************************************************
 *  RenderGlasses()
 *
 *  This method is called to render
 *  the shapes for the glasses sitting atop the book stack.
 ***********************************************************/
void SceneManager::RenderGlasses()
{
	// Create the left circular part of the frame

	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.75f, 0.5f, 0.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-9.0f, 1.75f, -0.25f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// golden metal texture for the frame of the glasses.
	/****************************************************************/
	// SetShaderColor(0.7, 0.7, 0.7, 1);
	SetShaderTexture("glasses");
	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTorusMesh();
	/****************************************************************/

	// Create the left lens for the glasses

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.75f, 0.05f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-9.0f, 1.7f, -0.3f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing in a light blue color and implementing
	// glassy transparent shader for the lens of the glasses.
	/****************************************************************/
	SetShaderColor(0.7, 0.7, 1.0, 0.25);
	SetShaderMaterial("glass");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// Create right circular part of the frame

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.75f, 0.5f, 0.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-7.0f, 1.75f, -0.25f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// golden metal texture for the frame of the glasses.
	/****************************************************************/
	// SetShaderColor(0.7, 0.7, 0.7, 1);
	SetShaderTexture("glasses");
	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTorusMesh();
	/****************************************************************/

	// Create the right lens for the glasses

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.75f, 0.05f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-7.0f, 1.7f, -0.3f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing in a light blue color and implementing
	// glassy transparent shader for the lens of the glasses.
	/****************************************************************/
	SetShaderColor(0.7, 0.7, 1.0, 0.25);
	SetShaderMaterial("glass");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// Create the middle support of the glasses, connecting the two circular frames together

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(4.0f, 0.14f, 0.07f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-8.0f, 2.24f, -0.26f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// golden metal texture for the frame of the glasses.
	/****************************************************************/
	// SetShaderColor(0.7, 0.7, 0.7, 1);
	SetShaderTexture("glasses");
	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// Create the second middle support of the glasses, connecting the two circular frames together

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.75f, 0.1f, 0.07f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-8.0f, 2.0f, -0.26f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// golden metal texture for the frame of the glasses.
	/****************************************************************/
	// SetShaderColor(0.7, 0.7, 0.7, 1);
	SetShaderTexture("glasses");
	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// Create the left temple of the frame

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(4.0f, 0.14f, 0.07f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-9.97f, 2.232f, -2.23f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// golden metal texture for the frame of the glasses.
	/****************************************************************/
	// SetShaderColor(0.7, 0.7, 0.7, 1);
	SetShaderTexture("glasses");
	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// Create the tip of the left temple of the frame

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.1f, 1.25f, 0.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 00.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-9.97f, 1.7f, -4.22f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing in a black color and implementing
	// glossy texture for the tip of the tip of the temple for the glasses.
	/****************************************************************/
	SetShaderColor(0.1, 0.1, 0.1, 1);
	SetShaderMaterial("glass");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// Create the right temple of the frame

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(4.0f, 0.14f, 0.07f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.04f, 2.232f, -2.23f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// golden metal texture for the frame of the glasses.
	/****************************************************************/
	// SetShaderColor(0.7, 0.7, 0.7, 1);
	SetShaderTexture("glasses");
	SetShaderMaterial("metal");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// Create the tip of the right temple of the frame

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.1f, 1.25f, 0.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 00.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.04f, 1.7f, -4.22f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing in a black color and implementing
	// glossy texture for the tip of the tip of the temple for the glasses.
	/****************************************************************/
	SetShaderColor(0.1, 0.1, 0.1, 1);
	SetShaderMaterial("glass");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/
}
/****************************************************************/
// Campbell Update: END OF SECTION FOR GLASSES
/****************************************************************/

/****************************************************************/
// Campbell Update: BEGINNING OF SECTION FOR MUG
/****************************************************************/
/***********************************************************
 *  RenderMug()
 *
 *  This method is called to render
 *  the shapes for the drinking mug.
 ***********************************************************/
void SceneManager::RenderMug()
{
	// Create the main part of the mug

	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 2.0f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-13.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// porcelain texture for the mug.
	/****************************************************************/
	// SetShaderColor(0.8, 0.8, 0.8, 1);
	SetShaderTexture("mug");
	SetShaderMaterial("mug");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh(false,true,true);
	/****************************************************************/

	// Create the water that will be inside the mug

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.99f, 1.0f, 0.99f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-13.0f, 0.75f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// porcelain texture for the mug.
	/****************************************************************/
	// SetShaderColor(0.8, 0.8, 0.8, 1);
	SetShaderTexture("water");
	SetShaderMaterial("mug");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// Create the handle of the mug

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 0.5f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-12.0f, 1.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/****************************************************************/
	// Campbell Update: Editing out color and implementing
	// porcelain texture for the mug.
	/****************************************************************/
	// SetShaderColor(0.8, 0.8, 0.8, 1);
	SetShaderTexture("mug");
	SetShaderMaterial("mug");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTorusMesh();
}
/****************************************************************/
// Campbell Update: END OF SECTION FOR MUG
/****************************************************************/